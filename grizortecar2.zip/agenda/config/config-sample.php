<?php
// Configurações de acesso ao banco de dados
define('DB_HOST', 'host');         // Endereço do servidor do banco de dados (ex: 'localhost' ou '127.0.0.1')
define('DB_USER', 'user');         // Nome de usuário para o banco de dados
define('DB_PASSWORD', 'password'); // Senha para o banco de dados
define('DB_NAME', 'dbname');       // Nome do banco de dados
?>