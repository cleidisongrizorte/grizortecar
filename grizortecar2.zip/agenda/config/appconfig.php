<?php

define('BASE_URL', '/grizortecar');

?>