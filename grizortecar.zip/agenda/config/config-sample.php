<?php

// Configurações de acesso ao banco de dados

    define('DB_HOST','host');
    define('DB_USER','user');
    define('DB_PASSWORD','password');
    define('DB_NAME','dbname');

?>