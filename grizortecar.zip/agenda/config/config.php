<?php
//Configuraçoes de acesso ao banco de dados

define('DB_HOST','localhost');
define('DB_USER','grizorte');
define('DB_PASSWORD','81654325');
define('DB_NAME','agenda');

?>