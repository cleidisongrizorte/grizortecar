</main>
<br><br>
<footer>
    <p style="text-align: center;">&copy; <?php echo date('Y'); ?> AgendaAqui - Todos os direitos reservados</p>
</footer>
</body>

</html>