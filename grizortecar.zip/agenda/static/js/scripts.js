function confirmarExclusao() {
    return confirm("Tem certeza que deseja excluir o item?");
}

function cancelarAgendamento() {
    return confirm("Tem certeza que deseja cancelar o agendamento?");
}