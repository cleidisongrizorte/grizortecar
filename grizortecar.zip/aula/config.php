<?php
//Configuraçoes de acesso ao banco de dados

$servidor = "localhost";
$dbusuario = "grizorte";
$dbsenha = "81654325";
$dbnome = "agenda";
$conn = mysqli_connect($servidor,$dbusuario,$dbsenha,$dbnome);

?>